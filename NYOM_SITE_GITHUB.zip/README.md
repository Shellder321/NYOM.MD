# NYOM MD — site público

Este diretório contém somente os arquivos públicos do site. Para conectar ao bot, abra `site-config.js` e preencha:

```js
window.NYOM_API_BASE = 'https://SEU-BACKEND-DO-BOT.example.com';
```

Não coloque tokens, API keys, `.env`, banco de dados ou arquivos do bot neste diretório. O site público precisa que o backend privado do bot esteja online e configurado para aceitar o domínio publicado no GitHub Pages.

Depois, publique o conteúdo desta pasta como GitHub Pages. Quando você enviar o novo link público, ele também deve ser configurado no bot em `DASHBOARD_PUBLIC_URL`; esse endereço será usado no botão do painel Anti-Selfbot.
